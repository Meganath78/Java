import java.util.*;
import java.lang.Math;
public class REMOVE_MSBIT
{
	public static void main(String[] args) 
	{   
                Scanner sc = new Scanner(System.in);
                int num, count;
                num = sc.nextInt();
                int bit_mask;
                bit_mask = 1;
                count=0;
                int max=0;
                while ( num >= bit_mask)
                        bit_mask <<=1;
                if (num == bit_mask)
                        num =0;
                else
                {  
                        bit_mask>>=1;
                        num = bit_mask^num;
                }
                System.out.println(num);
        }
	
}
                      