import java.util.*;
import java.lang.Math;
public class STRING_PROBLEM
{
	public static void main(String[] args) 
	{   
                String s1 ="abcdefghij google microsoftst";
                int len = s1.length();
                char[] ch = s1.toCharArray();
                int st_ind, ed_ind, ind, wkind, max, ctr, res_max, res_ctr,start,end;
                int[] freq = new int[27];
                System.out.println(len);
                ctr=0;
                String s2;
                String s3;
                res_max=0; 
                res_ctr =0;
                start =0; end =0;
                for ( ind =0, st_ind=0;ind < len; ind++)
                {
                        if (( ch[ind]== 32) && (ch[ind]!= '\0'))
                                {
                                        for (wkind =0, max = 0; wkind < 27; wkind++)
                                        {
                                                if ( max == freq[wkind])
                                                        ctr++;
                                                if ( max < freq[wkind])
                                                {
                                                        max = freq[wkind];
                                                        ctr=1;
                                                }
                                        }
                                        ed_ind = ind;
                                        //System.out.println(s2 +"  "+ max+ " "+ ctr );
                                        if ((res_max < max))
                                        {
                                                res_max = max;
                                                res_ctr = ctr;
                                                start = st_ind;
                                                end =  ed_ind;
                                        }
                                        else  if ((res_max == max)&& (res_ctr < ctr))
                                        {
                                                res_max = max;
                                                res_ctr = ctr;
                                                start = st_ind;
                                                end =  ed_ind;
                                        }
                                        st_ind= ind+1; 
                                        freq = new int[27];       
                                }
                                else if (( ch[ind]>= 'a') && ( ch[ind]<='z'))
                                        {
                                         freq[ch[ind]-96]++;
                                        }
                }
                for (wkind =0, max = 0; wkind < 27; wkind++)
                        {
                        if ( max == freq[wkind])
                                ctr++;
                        if ( max < freq[wkind])
                        {
                                max = freq[wkind];
                                ctr=1;
                        }
                        }
                        if ((res_max < max))
                        {
                                res_max = max;
                                res_ctr = ctr;
                                start = st_ind;
                                end =  len;
                        }
                        else  if ((res_max == max)&& (res_ctr < ctr))
                        {
                                res_max = max;
                                res_ctr = ctr;
                                 start = st_ind;
                                 end =  len;
                        }
                        s3 = s1.substring(start, end);
                        System.out.println(s3 +"  "+ res_max+ " "+ res_ctr );
        }

	
}
                      