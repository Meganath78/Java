import java.util.*;
import java.lang.Math;
public class ADJACENT_SETBIT
{
	public static void main(String[] args) 
	{   
                Scanner sc = new Scanner(System.in);
                int num, count;
                num = sc.nextInt();
                int bit_mask;
                bit_mask = 1;
                count=0;
                int max=0;
                while ( num >= bit_mask)
                        bit_mask <<=1;
                if ( (bit_mask-1) ==  num)
                        System.out.println("yes");
                else
                        System.out.println("No");
                System.out.println(max);
        }
	
}
                      