import java.util.*;
import java.lang.Math;
public class BIT_PRESENT_AT_POSITION_GVN
{
	public static void main(String[] args) 
	{   
                Scanner sc = new Scanner(System.in);
                int num, count;
                num = sc.nextInt();
                count = sc.nextInt();
                int bit_mask;
                bit_mask = 1;
                bit_mask = bit_mask << count-1;
                if (( num & bit_mask) == bit_mask)
                        System.out.println("PRESENT");
                else
                        System.out.println("NOT");

        }
	
}
                      