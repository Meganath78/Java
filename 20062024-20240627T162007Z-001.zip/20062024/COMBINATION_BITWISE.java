import java.util.*;
import java.lang.Math;
public class COMBINATION_BITWISE
{
	public static void main(String[] args) 
	{   
               int[] arr = new int[] { 1,2,3,4,5};
               int bit_mask, ind;
               int len = arr.length;
                int power;
                power =(int) Math.pow(2,len);
              for ( ind = 1; ind< power; ind+=1)
               {
                        int[] new_arr= new int[len];
                        int wk_ind,itr;
                        bit_mask =1;
                        wk_ind = 0;
                        itr =0;
                        while ( bit_mask<= ind)
                        {
                                if (( ind & bit_mask)==bit_mask)
                                {
                                        new_arr[itr] = arr[wk_ind];
                                        itr+=1;
                                }
                                wk_ind+=1;
                                bit_mask<<=1;
                        }
                        for ( itr =0; itr < len;itr++)
                        {
                                if ( new_arr[itr]==0)
                                        continue;
                                System.out.print(new_arr[itr]+" ");
                        }
                        System.out.println();
               }
        }
	
}
                      