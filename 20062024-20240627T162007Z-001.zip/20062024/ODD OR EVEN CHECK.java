import java.util.*;
import java.lang.Math;
public class EXAMPLE
{
	public static void main(String[] args) 
	{   
                Scanner sc = new Scanner(System.in);
                int num;
                num = sc.nextInt();
                int bit_mask;
                bit_mask = num;
                bit_mask  = bit_mask>>1;
                bit_mask = bit_mask<<1;
                if ( num == bit_mask)
                        System.out.println("EVEN");
                else
                        System.out.println("ODD");
                


        }
	
}
                      