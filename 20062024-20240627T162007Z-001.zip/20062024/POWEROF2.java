import java.util.*;
import java.lang.Math;
public class POWEROF2
{
	public static void main(String[] args) 
	{   
                Scanner sc = new Scanner(System.in);
                int num;
                num = sc.nextInt();
                int bit_mask, count;
                /*bit_mask = 1;
                count =0;
                while (num >= bit_mask)
                {
                        if (( num & bit_mask) == bit_mask)
                        count++;
                        bit_mask = bit_mask<<1;
                }
                if ( count == 1)*/
                if ( (num & (num -1)) == 0)
                        System.out.println("POWER of 2");                   
                else
                        System.out.println("Not");                
        }
	
}
                      