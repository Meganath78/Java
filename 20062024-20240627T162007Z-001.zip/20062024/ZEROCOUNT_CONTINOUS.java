import java.util.*;
import java.lang.Math;
public class ZEROCOUNT_CONTINOUS
{
	public static void main(String[] args) 
	{   
                Scanner sc = new Scanner(System.in);
                int num, count;
                num = sc.nextInt();
                int bit_mask;
                bit_mask = 1;
                count=0;
                int max=0;
                while ( num >= bit_mask)
                {
                        if (( num & bit_mask) == 0)
                                count+=1;
                        else
                        {
                                if ( max < count)
                                        max = count;
                                count =0;
                        }
                        bit_mask <<=1;
                }
                System.out.println(max);
        }
	
}
                      