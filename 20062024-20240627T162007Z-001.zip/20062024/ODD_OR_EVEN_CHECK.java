import java.util.*;
import java.lang.Math;
public class ODD_OR_EVEN_CHECK
{
	public static void main(String[] args) 
	{   
                Scanner sc = new Scanner(System.in);
                int num;
                num = sc.nextInt();
                if (( num & 1) == 1)
                        System.out.println("ODD");
                else
                        System.out.println("EVEN");

        }
	
}
                      