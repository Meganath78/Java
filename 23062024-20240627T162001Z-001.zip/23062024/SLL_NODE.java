import java.util.*;
class Node
{
        int data;
        Node add;
        Node(int data)
        {
                this.data = data;
                this.add = null;
        }
}
class SLL
{
        Node Head = null;
        Node Tail = null;
        Node prev = null;
        void create_List( int num)
        {
                Node newnode = new Node(num);// NODE CREATION CONSTRUCTOR
                if ( Head == null)//FIRST NODE
                        Head = newnode;
                else
                {
                        Tail = Head;
                        prev = Head;
                        while (( Tail != null) && (Tail.data < newnode.data))
                        {
                                prev = Tail;
                                Tail = Tail .add;
                        }// BEGIN
                       if((Tail == Head ) && ( newnode.data < Tail.data))
                                {
                                        newnode.add = Head;
                                        Head = newnode;
                                }
                        else if (Tail == null)// END 
                        {              
                                prev.add = newnode;
                        }
                        else// MIDDLE
                        {
                                prev.add = newnode;
                                newnode.add = Tail;
                        }
                }
        }
        void display()
        {
                Node tptr = Head;
                while(tptr != null)
                {
                        System.out.print(tptr.data+" ");
                        tptr = tptr.add;
                }
        }
}
public class SLL_NODE
{
        public static void main(String[] args)
        {
                int num;
                Scanner sc = new Scanner(System.in);
                SLL s = new SLL();
                while (true)
                {
                        num = sc.nextInt();
                        if ( num ==-1)
                                break;
                        s.create_List(num);
                }
                s.display();

        }
}