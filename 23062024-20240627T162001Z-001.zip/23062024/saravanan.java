import java.util.*;
class Node
{
        int data;
        Node next;
        Node(int data)
        {
                this.data = data;
                this.next = null;
        }
}
class SLL
{
        Node start = null;
        void Create_node_last(int data1)
        {
                Node newnode = new Node(data1);
                if (start == null)
                        start = newnode;
                else
                {
                        // curr = start;
                        // prev = start;
                        // while ( curr != null)
                        // {
                        //         prev = curr;
                        //         curr = curr.next;
                        // }
                        // if ( curr!= null)
                        // curr.next = newnode;
                        Node tptr = start;
                        while(tptr.next != null)
                        {
                                tptr = tptr.next;
                        }
                        tptr.next = newnode;
                }
        }
        void display()
        {
                Node tptr = null;
                tptr = start;
                while ( tptr!= null)
                {
                        System.out.println(tptr.data);
                        tptr = tptr.next;
                }
        }
}
public class saravanan
{
        public static void main(String[] args)
        {
                int num;
                Scanner sc = new Scanner(System.in);
                SLL s = new SLL();
                while (true)
                {
                        num = sc.nextInt();
                        if ( num ==-1)
                                break;
                        s.Create_node_last(num);
                }
                s.display();

        }
}