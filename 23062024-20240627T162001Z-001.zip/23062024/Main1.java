import java.util.Scanner;
class Node
{
        int data;
        Node next;
        Node(int data)
        {
                this.data = data;
                this.next = null;
        }
}
class slist
{
        Node start = null;
        Node last = null;
        Node tptr = null;
        void Create_list( int data)
        {
                Node newnode = new Node(data);
                if ( start == null)
                        start = last = newnode;
                else
                {
                        last.next = newnode;
                        last = newnode;
                }
        }
        void display()
        {
                tptr = start;
                while ( tptr.next != null)
                {
                        System.out.println(tptr.data);
                        tptr = tptr.next;
                }

        }
        void Delete_pos( int del_data)
        {

                tptr = start;
                Node prev = null;
                while ( tptr.data != del_data)
                {
                        prev=tptr;
                        tptr = tptr.next;
                }
                if (del_data== start.data)
                        start = start.next;
                else
                {
                        prev.next = tptr.next;
                }
        }

}
public class Main1
{
        public static void main(String[] args) 
        {
                Scanner input = new Scanner(System.in);
                int num;
                slist sll = new slist();
                while ( true)
                {
                        num = input.nextInt();
                        if (num ==-1)
                           break;
                        sll.Create_list( num );
                }
                sll.display();
                num = input.nextInt();
                sll.Delete_pos(num);
                sll.display();
                

        }
}