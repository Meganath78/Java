import java.util.*;
public class Node
{
        int data;
        Node addr;
        Node (int data)
        {
                this.data = data;
                this.addr = null;
        }
}
public class SLL_NODE_CREATION
{	
         public static void main(String[] args) 	
	{   
                Scanner input = new Scanner(System.in);
                int num;
                
                while ( true)
                {
                        num= input.nextInt();
                        if ( num ==-1)
                                break;
                        Node newnNode = new Node(num);
                        System.out.println(newnNode.data);
                }

	}   
        
}
                