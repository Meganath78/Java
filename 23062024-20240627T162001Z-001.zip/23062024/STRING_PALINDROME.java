import java.util.*;
import java.lang.Math;
public class STRING_PALINDROME
{	
         public static void main(String[] args) 	
	{   
                Scanner input = new Scanner(System.in);
                                

	}   
        
}
                