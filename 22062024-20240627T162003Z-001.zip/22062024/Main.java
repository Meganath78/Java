import java.util.*;
class Node 
{
        int data;
        Node add; 
        Node(int data)
        {
                this.data = data;
                this.add = null;
        }
}
class List 
{
        Node Head = null;
        Node Tail = null;
        Node prev = null;
        void create_List( int num)
        {
                Node newnode = new Node(num);// NODE CREATION CONSTRUCTOR
                if ( Head == null)//FIRST NODE
                        Head = newnode;
                else
                {
                        Tail = Head;
                        prev = Head;
                        while (( Tail != null) && (Tail.data < newnode.data))
                        {
                                prev = Tail;
                                Tail = Tail .add;
                        }// BEGIN
                       if((Tail == Head ) && ( newnode.data < Tail.data))
                                {
                                        newnode.add = Head;
                                        Head = newnode;
                                }
                        else if (Tail == null)// END 
                        {              
                                prev.add = newnode;
                        }
                        else// MIDDLE
                        {
                                prev.add = newnode;
                                newnode.add = Tail;
                        }
                }
        }
        void positional_insert( int data, int pos)
        {
                Node newnode =new Node(data);
                // traverse the list using position
                int itr;
                for (itr = 1, Tail = Head, prev = Head;((Tail != null) && (itr<=pos));
                                                        prev = Tail , Tail = Tail.add, itr++);
               // tail == NULL, // 
               if (pos ==0)
                        {
                        newnode.add = Head;
                        Head = newnode;
                        }
               else if (Tail == null)// END 
                        {              
                                prev.add = newnode;
                        }
                else
                        {
                                prev.add = newnode;
                                newnode.add = Tail;    
                        }
                        
        }
        void display()
        {
                Node tptr = Head;
                while(tptr != null)
                {
                        System.out.print(tptr.data+" ");
                        tptr = tptr.add;
                }
        }
}
public class Main
{
        public static void main(String[] args)
        {
                Scanner input = new Scanner(System.in);
                List L1 = new List();
                int num;
                while(true)
                {
                        num = input.nextInt();
                        if(num == -1) break;
                        L1.create_List(num);
                }
                L1.display();
                System.out.println("Enter position and element to insert");
                num = input.nextInt();
                int pos;
                pos = input.nextInt();
                L1.positional_insert( num, pos);
                L1.display();



        }
}