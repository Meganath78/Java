import java.util.*;
import java.lang.Math;
public class TAYLOR_SERIES_RE
{	
        static double sum;
	public static void main(String[] args) 	
	{   
               double num, xterm;  
               Scanner sc = new Scanner(System.in);
                xterm = sc.nextDouble();
                num = sc.nextDouble();
                System.out.println(taylor_series(xterm, num));
	}
        public static double taylor_series( double xterm, double num)
        {
                double quot, denom;
                if ( num < 0)
                        return sum;
                quot = power_num( xterm, num);
                denom = factorial( num);
                sum+=(quot/denom);
                return taylor_series( xterm, num-1);
        }
        public static double power_num(double base, double expo)
        {
                if ( expo == 0)
                        return 1;
                return base * power_num(base,expo-1);
        }
        public static double factorial( double num)
        {
                if ( num ==0)
                        return 1;
                return num * factorial(num-1);
        }
        
}
                      