import java.util.*;
import java.lang.Math;
public class TAYLOR_SERIES_RE_OPTIMIZATION
{	
        static double sum, quot, denom;
         public static void main(String[] args) 	
	{   
               double num, xterm;  
               Scanner sc = new Scanner(System.in);
                xterm = sc.nextDouble();
                num = sc.nextDouble();
                System.out.println(taylor_series(xterm, num));
	}
        public static double taylor_series( double xterm, double num)
        {
                
                if ( num < 0)
                {
                        quot = 1;
                        denom =1;
                        return 1;
                }         
                taylor_series( xterm, num-1);
                sum+= (quot/denom);
                quot = quot * xterm;
                denom = denom * (num+1);
                return sum;
        }
        
}
                      