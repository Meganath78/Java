import java.util.*;
import java.lang.Math;
public class STRING_PALINDROME
{	
         public static void main(String[] args) 	
	{   
                Scanner input = new Scanner(System.in);
                String s1 = input.nextLine();
                char[] str = s1.toCharArray();
                int ind, len, wkind;
                String sub1 = "";
                String sub2 = "";
                String sub0 = "";
                len = s1.length();
                boolean FLAG;
                FLAG = false;
                for ( wkind =0; wkind < len-1;wkind++)
                {
                        sub0 = s1.substring(0,wkind+1);
                        if((Is_palindrome(sub0)) == true)
                        {
                                for ( ind =wkind+1; ind < len-1; ind++)
                                {
                                        sub1 = s1.substring(wkind+1, ind+1);
                                        sub2 = s1.substring(ind+1);
                                        if ((Is_palindrome(sub1)) && (Is_palindrome(sub2)) == true)
                                                {
                                                        FLAG=true;
                                                        break;
                                                }
                                }
                                if(FLAG==true)
                                        break;
                        }
                }
                if ( FLAG == true)
                        System.out.println(sub0+"  "+sub1+" "+sub2);
                else
                        System.out.println("No");                

	}   
        public static boolean Is_palindrome ( String s)
        {
                StringBuilder S1 = new StringBuilder(s);
                S1.reverse();
                String S2 = new String(S1);
                return s.equals(S2);
        }
}
//NooNMALAYALAM   
//aaaba                 