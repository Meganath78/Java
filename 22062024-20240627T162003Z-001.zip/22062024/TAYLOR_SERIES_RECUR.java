import java.util.*;
import java.lang.Math;
public class TAYLOR_SERIES_RECUR
{	
        static double sum;
	public static void main(String[] args) 	
	{   
               int num, xterm;  
               Scanner sc = new Scanner(System.in);
                System.out.println(power_num(2,4));
                System.out.println("Hello");
	}
        public static taylor_series ( int xterm, int num)
        {
                int quot, denom;
                if ( num < 0)
                        return sum;
                quot = power_num( xterm, num);
                denom = factorial( num);
                System.out.println(double(quot/denom));
                taylor_series( xterm, num-1);

        }
        public static double power_num(double base, int expo)
        {
                if ( expo == 0)
                        return 1;
                return base * power_num(base,expo-1);
        }
        public static int factorial( int num)
        {
                if ( num ==0)
                        return 1;
                return num * factorial(num-1);
        }
        
}
                      