class Node :
        def __init__(self,data):
                self.data = data
                self.add = None
class List :
        Head = None
        Tail = None
        def create_List(self,num):
                newnode = Node(num)
                if self.Head == None:
                        self.Head = newnode
                        self.Tail = newnode
                else:
                        self.Tail.add = newnode
                        self.Tail = newnode
        def display(self):
                tptr = self.Head
                while tptr != None:
                        print(tptr.data,end=" ")
                        tptr = tptr.add

L1 = List()
while 1:
        num = int(input())
        if num == -1:
                break
        L1.create_List(num)
L1.display()