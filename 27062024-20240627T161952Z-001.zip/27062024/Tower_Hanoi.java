import java.util.*;
class stack
{
        int top =-1;
        int[] stk;
        stack(int size)
        {
                this. stk = new int[size];
        }
        boolean Is_empty( )
        {
                if (top==-1)
                        return true;
                else
                        return false;
        }
        int Peek()
        {
                if ( this.top!= -1)
                        return this.stk[top];
                return -1;
        }
        void Push( int ch1)
        {
                top++;
                this.stk[top] = ch1; 
        }
        int Pop()
        {
                int s;
                if (this.top ==-1)
                        return -1;
                s = stk[top];
                top--;
                return s;
        }
}

public class Tower_Hanoi
{
                public static void main( String args[])
        {
                Scanner inp = new Scanner( System.in);
                int size;
                size  = inp.nextInt();
                stack src = new stack(size);
                int ind;
                for ( ind =0; ind< size; ind++ )
                        src.Push(size-ind);
                stack des = new stack(size);
                stack tem = new stack(size);
                for (ind=size-1; ind >=0; ind--)
                {
                        System.out.println("SRC"+src.stk[ind]+" DES "+des.stk[ind]+" TEM "+tem.stk[ind]);
                }
                int val, ctr;
                ctr =0;
                while ( true )
                { //SRC and DES
                        ctr++;
                        if( src.Is_empty()==true)//RECEIVER
                        {
                                val = des.Pop();
                                des.stk[des.top+1]=0;
                                src.Push(val);
                        }
                        else if ( des.Is_empty()==true)
                        {       
                                val = src.Pop();
                                src.stk[src.top+1]=0;
                                des.Push(val);
                        }
                        else
                        {
                                if (src.Peek() < des.Peek())
                                {
                                        val = src.Pop();
                                        src.stk[src.top+1]=0;
                                        des.Push(val);
                                        if ( des.top == size-1)
                                                break;
                                }
                                else
                                { 
                                        val = des.Pop();
                                        des.stk[des.top+1]=0;
                                        src.Push(val);        
                                }
                        }
                        if ( des.top == size-1)
                                break;
                        // SRC to TEM
                        ctr++;
                        if( src.Is_empty()==true)//RECEIVER
                        {
                                val = tem.Pop();
                                tem.stk[tem.top+1]=0;
                                src.Push(val);
                        }
                        else if ( tem.Is_empty()==true)
                        {       
                                val = src.Pop();
                                src.stk[src.top+1]=0;
                                tem.Push(val);
                        }
                        else
                        {
                                if (src.Peek() < tem.Peek())
                                {
                                        val = src.Pop();
                                        src.stk[src.top+1]=0;
                                        tem.Push(val);
                                        if ( tem.top== size-1)
                                                break;
                                }
                                else
                                { 
                                        val = tem.Pop();
                                        tem.stk[tem.top+1]=0;
                                        src.Push(val);        
                                }
                        }
                        if (tem.top== size-1)
                        break;
                        //DES TO TEM
                        ctr++;
                        if( tem.Is_empty()==true)//RECEIVER
                        {
                                val = des.Pop();
                                des.stk[des.top+1]=0;
                                tem.Push(val);
                        }
                        else if ( des.Is_empty()==true)
                        {       
                                val = tem.Pop();
                                tem.stk[tem.top+1]=0;
                                des.Push(val);
                        }
                        else
                        {
                                if (tem.Peek() < des.Peek())
                                {
                                        val = tem.Pop();
                                        tem.stk[tem.top+1]=0;
                                        des.Push(val);
                                        if ( des.top == size-1)
                                                break;
                                }
                                else
                                { 
                                        val = des.Pop();
                                        des.stk[des.top+1]=0;
                                        tem.Push(val); 
                                        if ( tem.top == size-1)
                                                break;
                                }
                        }
                        if (( des.top == size-1) || ( tem.top == size-1))
                                break;
                               
                }
                System.out.println("RESULT");
                for (ind=size-1; ind >=0; ind--)
                {
                        System.out.println("SRC"+src.stk[ind]+" DES "+des.stk[ind]+" TEM "+tem.stk[ind]);
                }
                System.out.println("STEPS = "+ctr);
                
                
        }
}
