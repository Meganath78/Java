import java.util.*;
public class Heap_sort
{
        public static int[] Max_heapify( int[] arr, int parent,int scope)//14
        {
                int lef_child;
                int rig_child;
                int temp;
                lef_child = (parent*2) +1;
                rig_child = (parent*2) +2;//lef_child+1;
                //leaf node
                if ( lef_child > scope )
                        return arr;
                if ( lef_child == scope)//one child
                {
                        if (arr[parent] < arr[lef_child])
                        {
                                temp = arr[parent];
                                arr[parent] = arr[lef_child];
                                arr[lef_child] = temp;
                        }
                }
                else if(arr[lef_child] > arr[rig_child])// two child
                {
                        if (arr[parent] < arr[lef_child])
                        {
                                temp = arr[parent];
                                arr[parent] = arr[lef_child];
                                arr[lef_child] = temp;
                                return Max_heapify(arr, lef_child,scope);
                        }
                }
                else
                {
                        if (arr[parent] < arr[rig_child])
                        {
                                temp = arr[parent];
                                arr[parent] = arr[rig_child];
                                arr[rig_child] = temp;
                                return Max_heapify(arr, rig_child, scope);
                        }
                }
                return arr;
        }
        public static void main( String args[])
        {
                //int[] arr = new int[]{5,15,10,25,55,35,75,45,95,50,70,40,60,90,3};
                int[] arr = new int[]{12,3,56,7,89,34,56,90,33,16,73,25,68,9,23,45,37,40,59};
                int len;
                len = arr.length;
                int ind;
                int temp;
                for ( ind =0; ind < len; ind++)
                        System.out.print(arr[ind]+" ");
                
                int parent, scope;
                scope = len-1; 
                while (scope>0)
                {
                        parent = (scope+1)/2;
                        parent-=1;
                        while ( parent >=0)
                        {
                                arr = Max_heapify( arr, parent, scope);
                                parent-=1;      
                        }
                        temp = arr[0];
                        arr[0] = arr[scope];
                        arr[scope] = temp;
                        scope-=1;
                }
                System.out.println("Display");
                for ( ind =0; ind < len; ind++)
                        System.out.print(arr[ind]+" ");
                

        }
}
