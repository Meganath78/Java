import java.util.*;
class stack
{
        int top =-1;
        int[] stk;
        stack(int size)
        {
                this. stk = new int[size];
        }
        boolean Is_empty( )
        {
                if (top==-1)
                        return true;
                else
                        return false;
        }
        int Peek()
        {
                if ( this.top!= -1)
                        return this.stk[top];
                return -1;
        }
        void Push( int ch1)
        {
                top++;
                this.stk[top] = ch1; 
        }
        int Pop()
        {
                int s;
                if (this.top ==-1)
                        return -1;
                s = stk[top];
                top--;
                return s;
        }
}

public class Histogram
{
        public static void main( String args[])
        {
                int[] arr;
                int size;
                Scanner inp = new Scanner(System.in);
                size = inp.nextInt();
                arr = new int[size];
                int ind, wkind, max, area;
                for ( ind =0; ind < size; ind++)
                        arr[ind]= inp.nextInt();
                max =0;
                for ( ind =0; ind < size; ind++)
                {
                        stack st = new stack(size);
                        st.Push(arr[ind]);
                        //LEFT
                        for ( wkind = ind-1; ((wkind >=0) && ( arr[wkind] >= arr[ind])); wkind-=1)
                               st.Push(wkind);
                        //RIGHT
                        for ( wkind = ind+1; ((wkind < size) && ( arr[wkind] >= arr[ind])); wkind+=1)
                                st.Push(wkind);

                        area = st.stk[0]*(st.top+1);
                        if (max < area)
                                max = area;
                }
                System.out.println(max);
                 
                
        }
}
